package com.alan.luszczak.costamcostam;

import androidx.lifecycle.ViewModel;

public class ScoreViewModel extends ViewModel {
    public int scoreA = 0, scoreB = 0;
}
