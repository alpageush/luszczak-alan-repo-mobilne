package com.alan.luszczak.costamcostam;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ScoreViewModel svm;
    TextView teamALabel, teamBLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        teamALabel = findViewById(R.id.teamALabel);
        teamBLabel = findViewById(R.id.teamBLabel);

        svm = new ViewModelProvider(this).get(ScoreViewModel.class);
        teamALabel.setText(svm.scoreA+"");
        teamBLabel.setText(svm.scoreB+"");
    }

    private void addPoint(int p, String team) {
        if(team == "A") svm.scoreA += p;
        else svm.scoreB += p;
        teamALabel.setText(svm.scoreA+"");
        teamBLabel.setText(svm.scoreB+"");
    }

    public void plusFreeA(View view) {
        addPoint(1, "A");
    }

    public void plusFreeB(View view) {
        addPoint(1, "B");
    }

    public void plus2A(View view) {
        addPoint(2, "A");
    }

    public void plus2B(View view) {
        addPoint(2, "B");
    }

    public void plus3A(View view) {
        addPoint(3, "A");
    }

    public void plus3B(View view) {
        addPoint(3, "B");
    }

    public void reset(View view) {
        svm.scoreA = 0;
        svm.scoreB = 0;
        teamALabel.setText("0");
        teamBLabel.setText("0");
    }
}